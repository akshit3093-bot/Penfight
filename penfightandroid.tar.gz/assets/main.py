# /// script
# dependencies = [
#     "pygame-ce",
#     "cffi",
#     "pymunk",
# ]
# ///


import asyncio
import pygame
import pymunk
import math
import random

pygame.init()
WIDTH, HEIGHT = 1040, 690
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pen Fight")
clock = pygame.time.Clock()

# Fonts (with clean fallbacks for mobile WebAssembly/Android environments)
chalk_title_font = pygame.font.SysFont("comicsansms,arial", 38, bold=True)
chalk_sub_font = pygame.font.SysFont("comicsansms,arial", 18, bold=True)
chalk_card_title = pygame.font.SysFont("comicsansms,arial", 18, bold=True)
chalk_body_font = pygame.font.SysFont("comicsansms,arial", 13)
chalk_pill_font = pygame.font.SysFont("comicsansms,arial", 14, bold=True)

title_font = pygame.font.SysFont("arial", 36, bold=True)
big_font = pygame.font.SysFont("arial", 28, bold=True)
font = pygame.font.SysFont("arial", 18, bold=True)
med_font = pygame.font.SysFont("arial", 14, bold=True)
small_font = pygame.font.SysFont("arial", 13)

DESK_RECT = pygame.Rect(220, 165, 600, 390)

FLOOR_COLOR = (28, 31, 39)
CARD_BG = (44, 48, 60)
CARD_HOVER = (62, 68, 84)

MAX_PULL = 200
PHYSICS_SUBSTEPS = 4
FALL_ANIM_FRAMES = 48

# --- 4 Core Nostalgic Pens ---
CORE_PENS = [
    {
        "id": "045_fine",
        "name": "045 Fine",
        "subtitle": "Slim Ballpoint",
        "has_cap": True,
        "strength": "+ Long range & high spin",
        "weakness": "- Featherweight (gets launched)",
        "cap_off_desc": "CAP OFF: +25% speed & razor spin, ultra-light!",
        "boost_desc": "OVERDRIVE: +45% speed & extra glide!",
        "length": 126,
        "thickness": 10,
        "mass": 1.0,
        "spin_mult": 1.15,
        "power_mult": 3.5,
        "friction_drag": 0.968,
        "elasticity": 0.72,
    },
    {
        "id": "perm_marker",
        "name": "Permanent Marker",
        "subtitle": "Heavy Teacher's Marker",
        "has_cap": True,
        "strength": "+ Heavy knockback & solid speed",
        "weakness": "- Almost zero spin / slow turn",
        "cap_off_desc": "CAP OFF: Sheds heavy cap for +22% faster chase speed!",
        "boost_desc": "JUGGERNAUT: +50% knockback & heavy mass!",
        "length": 116,
        "thickness": 16,
        "mass": 2.9,
        "spin_mult": 3.8,
        "power_mult": 7.4,
        "friction_drag": 0.952,
        "elasticity": 0.65,
    },
    {
        "id": "rubber_grip",
        "name": "Rubber Grip",
        "subtitle": "Ribbed Grip Pen",
        "has_cap": True,
        "strength": "+ High grip brakes & resists hazards",
        "weakness": "- Shorter slide range",
        "cap_off_desc": "CAP OFF: Exposed tip gives maximum rubber braking!",
        "boost_desc": "REALIGN: Tap < ROTATE > buttons to aim!",
        "length": 112,
        "thickness": 13,
        "mass": 1.75,
        "spin_mult": 2.0,
        "power_mult": 4.8,
        "friction_drag": 0.924,
        "elasticity": 0.68,
    },
    {
        "id": "highlighter",
        "name": "Highlighter",
        "subtitle": "Chisel-Tip Marker",
        "has_cap": True,
        "strength": "+ Super bouncy & wide corner slap",
        "weakness": "- Wild ricochets (risks self-out)",
        "cap_off_desc": "CAP OFF: Narrower front & high-spin felt tip!",
        "boost_desc": "CHAOS MODE: Mega-bounce & wild spin!",
        "length": 88,
        "thickness": 24,
        "mass": 1.95,
        "spin_mult": 1.25,
        "power_mult": 5.6,
        "friction_drag": 0.958,
        "elasticity": 0.94,
    },
]

# --- 3 Free Play Special School Items ---
SPECIAL_ITEMS = [
    {
        "id": "pencil",
        "name": "Wooden Pencil",
        "subtitle": "Hexagonal Graphite Pencil",
        "has_cap": False,
        "strength": "+ Extra-long reach & sweeping spin",
        "weakness": "- Light wood body, low bounce",
        "cap_off_desc": "",
        "boost_desc": "",
        "length": 142,
        "thickness": 10,
        "mass": 1.15,
        "spin_mult": 1.1,
        "power_mult": 3.8,
        "friction_drag": 0.960,
        "elasticity": 0.58,
    },
    {
        "id": "chalk",
        "name": "Chalk Stick",
        "subtitle": "Dusty Blackboard Chalk",
        "has_cap": False,
        "strength": "+ Dead-stop grip & leaves chalk trail",
        "weakness": "- Very light & fragile momentum",
        "cap_off_desc": "",
        "boost_desc": "",
        "length": 78,
        "thickness": 14,
        "mass": 0.95,
        "spin_mult": 1.4,
        "power_mult": 3.2,
        "friction_drag": 0.915,
        "elasticity": 0.45,
    },
    {
        "id": "eraser",
        "name": "Long Eraser",
        "subtitle": "Heavy Rubber Brick",
        "has_cap": False,
        "strength": "+ Massive weight & pinball bounce",
        "weakness": "- Very slow slide & tiny range",
        "cap_off_desc": "",
        "boost_desc": "",
        "length": 74,
        "thickness": 30,
        "mass": 3.4,
        "spin_mult": 3.2,
        "power_mult": 6.2,
        "friction_drag": 0.910,
        "elasticity": 1.05,
    },
]

ALL_ITEMS = CORE_PENS + SPECIAL_ITEMS

# --- 4 Desk Surfaces ---
SURFACES = [
    {
        "id": "fresh",
        "name": "Fresh Hard Desk",
        "tagline": "Balanced classic wood",
        "desc": "Smooth, predictable friction and clean bounces.",
        "desk_color": (194, 154, 108),
        "grain_color": (182, 142, 96),
        "border_color": (125, 90, 54),
        "drag_offset": 0.0,
        "slope_pull": 0.0,
    },
    {
        "id": "worn",
        "name": "Worn-Out Desk",
        "tagline": "Random streaks & Dead Zone",
        "desc": "Scuff streaks deflect shots; big gouge traps pens!",
        "desk_color": (166, 132, 94),
        "grain_color": (148, 115, 80),
        "border_color": (105, 76, 48),
        "drag_offset": -0.004,
        "slope_pull": 0.0,
    },
    {
        "id": "laminated",
        "name": "Laminated Table",
        "tagline": "Slick dark slate gloss",
        "desc": "Pens glide far & spin longer—easy to overshoot!",
        "desk_color": (56, 70, 82),
        "grain_color": (68, 84, 98),
        "border_color": (34, 42, 50),
        "drag_offset": 0.016,
        "slope_pull": 0.0,
    },
    {
        "id": "angled",
        "name": "Angled Desk",
        "tagline": "Perpendicular downward tilt",
        "desc": "Curves moving shots toward bottom edge; holds on stop.",
        "desk_color": (186, 144, 104),
        "grain_color": (172, 132, 92),
        "border_color": (118, 82, 50),
        "drag_offset": 0.001,
        "slope_pull": 38.0,
    },
]

MODES = [
    {
        "id": "freeplay",
        "title": "FREE PLAY",
        "tag": "Best-of Series + Special Items",
        "desc": [
            "• Best of 3, 5, 7, 9, or 11 rounds",
            "• Unlocks Pencil, Chalk & Eraser!",
            "• Swap items from box each round"
        ],
        "chalk_accent": (145, 210, 255)
    },
    {
        "id": "knockout",
        "title": "ARCADE: KNOCKOUT",
        "tag": "4-Pen Box • King of the Hill",
        "desc": [
            "• Pick surface; 4 pens in Pencil Box",
            "• Winner STAYS where they landed!",
            "• Knocked-out pens grey out in box"
        ],
        "chalk_accent": (255, 165, 150)
    },
    {
        "id": "tactical",
        "title": "ARCADE: TACTICAL",
        "tag": "Contact Rule • 1-Turn Boosts",
        "desc": [
            "• 4-pen Box + swap between rounds",
            "• Hit opponent or give 1-turn BOOST!",
            "• Cap On/Off once per pen per round"
        ],
        "chalk_accent": (155, 240, 185)
    }
]

OPPONENT_OPTIONS = [
    {"id": "2p", "label": "2 Players", "sub": "Pass & Play", "color": (145, 210, 255)},
    {"id": "topper", "label": "vs Topper", "sub": "Easy CPU", "color": (155, 240, 185)},
    {"id": "regular", "label": "vs Class Regular", "sub": "Medium CPU", "color": (255, 225, 125)},
    {"id": "backbencher", "label": "vs Backbencher", "sub": "Hard CPU", "color": (255, 150, 140)},
]

SERIES_OPTIONS = [3, 5, 7, 9, 11]

P1_THEME = {"primary": (35, 110, 230), "accent": (140, 195, 255), "box_bg": (28, 52, 92), "label": "Player 1"}
P2_THEME = {"primary": (225, 55, 55), "accent": (255, 165, 165), "box_bg": (88, 32, 36), "label": "Player 2"}

BOX_W, BOX_H = 172, 46
P1_BOX_RECT = pygame.Rect(20, 52, BOX_W, BOX_H)
P2_BOX_RECT = pygame.Rect(WIDTH - 20 - BOX_W, 52, BOX_W, BOX_H)

P1_SPAWN = (DESK_RECT.x + 135, DESK_RECT.centery)
P2_SPAWN = (DESK_RECT.right - 135, DESK_RECT.centery)

# Mobile Touch UI Buttons (Finger-friendly hitboxes)
MENU_BTN_RECT = pygame.Rect(WIDTH // 2 - 44, HEIGHT - 44, 88, 34)
CAP_BTN_RECT = pygame.Rect(WIDTH // 2 - 95, 74, 190, 36)
ROT_LEFT_RECT = pygame.Rect(WIDTH // 2 - 195, 114, 92, 36)
ROT_RIGHT_RECT = pygame.Rect(WIDTH // 2 + 103, 114, 92, 36)
REPLAY_BTN_RECT = pygame.Rect(WIDTH // 2 - 175, HEIGHT - 50, 165, 40)
END_MENU_BTN_RECT = pygame.Rect(WIDTH // 2 + 10, HEIGHT - 50, 165, 40)
SETUP_BACK_RECT = pygame.Rect(24, 24, 110, 38)

def get_p2_name():
    if opponent_mode == "2p":
        return "Player 2"
    return next(o["label"].replace("vs ", "") for o in OPPONENT_OPTIONS if o["id"] == opponent_mode)

def get_box_rect(player_idx):
    return P1_BOX_RECT if player_idx == 0 else P2_BOX_RECT

def get_dropdown_tray_rect(player_idx, is_freeplay):
    box = get_box_rect(player_idx)
    if is_freeplay:
        tray_w = 346
        tray_x = box.x if player_idx == 0 else box.right - tray_w
        return pygame.Rect(tray_x, box.bottom + 4, tray_w, 4 * 58 + 28)
    else:
        tray_w = 180
        tray_x = box.x if player_idx == 0 else box.right - tray_w
        return pygame.Rect(tray_x, box.bottom + 4, tray_w, 4 * 58 + 10)

def get_dropdown_slot_rect(player_idx, item_idx, is_freeplay):
    tray = get_dropdown_tray_rect(player_idx, is_freeplay)
    if not is_freeplay:
        return pygame.Rect(tray.x + 5, tray.y + 5 + item_idx * 58, tray.width - 10, 54)
    else:
        col = 0 if item_idx < 4 else 1
        row = item_idx if item_idx < 4 else (item_idx - 4)
        col_w = (tray.width - 15) // 2
        sx = tray.x + 5 + col * (col_w + 5)
        sy = tray.y + 24 + row * 58
        return pygame.Rect(sx, sy, col_w, 54)

def pens_touching(pen_a, pen_b, padding=1.5):
    verts_a = [pen_a["body"].local_to_world(v) for v in pen_a["shape"].get_vertices()]
    verts_b = [pen_b["body"].local_to_world(v) for v in pen_b["shape"].get_vertices()]

    for poly in (verts_a, verts_b):
        for i in range(len(poly)):
            p1 = poly[i]
            p2 = poly[(i + 1) % len(poly)]
            nx = -(p2.y - p1.y)
            ny = p2.x - p1.x
            length = math.hypot(nx, ny)
            if length == 0:
                continue
            nx /= length
            ny /= length

            min_a = min(v.x * nx + v.y * ny for v in verts_a) - padding
            max_a = max(v.x * nx + v.y * ny for v in verts_a) + padding
            min_b = min(v.x * nx + v.y * ny for v in verts_b)
            max_b = max(v.x * nx + v.y * ny for v in verts_b)

            if max_a < min_b or max_b < min_a:
                return False
    return True

def get_effective_specs(spec, cap_on):
    l = spec["length"]
    t = spec["thickness"]
    mass = spec["mass"]
    spin_mult = spec["spin_mult"]
    power_mult = spec["power_mult"]
    drag = spec["friction_drag"]
    elast = spec["elasticity"]

    if not spec.get("has_cap", False) or cap_on:
        return l, t, mass, spin_mult, power_mult, drag, elast

    pid = spec["id"]
    if pid == "045_fine":
        l -= 14
        mass *= 0.78
        spin_mult *= 0.75
        power_mult *= 1.05
    elif pid == "perm_marker":
        l -= 16
        mass *= 0.80
        power_mult *= 1.18
        spin_mult *= 0.82
    elif pid == "rubber_grip":
        l -= 12
        mass *= 0.88
        drag -= 0.016
    elif pid == "highlighter":
        l -= 14
        t -= 4
        mass *= 0.88
        spin_mult *= 0.78
        elast = 0.98

    return l, t, mass, spin_mult, power_mult, drag, elast

def create_pen(space, x, y, angle, spec, theme, player_label, cap_on=True):
    l, t, mass, spin_mult, _, _, elast = get_effective_specs(spec, cap_on)
    moment = pymunk.moment_for_box(mass, (l, t)) * spin_mult
    body = pymunk.Body(mass, moment)
    body.position = (x, y)
    body.angle = angle
    shape = pymunk.Poly.create_box(body, (l, t))
    shape.elasticity = elast
    shape.friction = 0.5
    space.add(body, shape)
    return {
        "body": body,
        "shape": shape,
        "spec": spec,
        "theme": theme,
        "cap_on": cap_on,
        "cap_toggled_this_round": False,
        "eff_length": l,
        "eff_thickness": t,
        "name": f"{player_label} ({spec['name']})"
    }

def toggle_pen_cap(space, pen):
    spec = pen["spec"]
    if not spec.get("has_cap", False) or pen["cap_toggled_this_round"]:
        return False

    pen["cap_on"] = not pen["cap_on"]
    pen["cap_toggled_this_round"] = True

    l, t, mass, spin_mult, _, _, elast = get_effective_specs(spec, pen["cap_on"])
    pen["eff_length"] = l
    pen["eff_thickness"] = t

    body = pen["body"]
    old_shape = pen["shape"]
    space.remove(old_shape)

    body.mass = mass
    body.moment = pymunk.moment_for_box(mass, (l, t)) * spin_mult
    new_shape = pymunk.Poly.create_box(body, (l, t))
    new_shape.elasticity = elast
    new_shape.friction = 0.5
    space.add(new_shape)
    pen["shape"] = new_shape
    return True

def point_in_oriented_ellipse(pt, hazard):
    dx = pt[0] - hazard["pos"][0]
    dy = pt[1] - hazard["pos"][1]
    cos_a = math.cos(-hazard["angle"])
    sin_a = math.sin(-hazard["angle"])
    lx = dx * cos_a - dy * sin_a
    ly = dx * sin_a + dy * cos_a
    rx, ry = hazard["rx"], hazard["ry"]
    return (lx * lx) / (rx * rx) + (ly * ly) / (ry * ry) <= 1.0

def generate_worn_hazards():
    hazards = []

    def far_from_spawns(px, py, clearance):
        return (
            math.hypot(px - P1_SPAWN[0], py - P1_SPAWN[1]) >= clearance
            and math.hypot(px - P2_SPAWN[0], py - P2_SPAWN[1]) >= clearance
        )

    for _ in range(200):
        px = random.randint(DESK_RECT.left + 120, DESK_RECT.right - 120)
        py = random.randint(DESK_RECT.top + 85, DESK_RECT.bottom - 85)
        if far_from_spawns(px, py, 115):
            hazards.append({
                "kind": "deadzone",
                "pos": (px, py),
                "rx": random.randint(58, 72),
                "ry": random.randint(42, 54),
                "angle": random.uniform(-0.4, 0.4),
            })
            break

    attempts = 0
    while sum(1 for h in hazards if h["kind"] == "streak") < 3 and attempts < 400:
        attempts += 1
        px = random.randint(DESK_RECT.left + 90, DESK_RECT.right - 90)
        py = random.randint(DESK_RECT.top + 65, DESK_RECT.bottom - 65)
        if not far_from_spawns(px, py, 95):
            continue
        if all(math.hypot(px - h["pos"][0], py - h["pos"][1]) >= 125 for h in hazards):
            hazards.append({
                "kind": "streak",
                "pos": (px, py),
                "rx": random.randint(52, 74),
                "ry": random.randint(11, 16),
                "angle": random.uniform(-1.1, 1.1),
            })

    attempts = 0
    while sum(1 for h in hazards if h["kind"] == "patch") < 3 and attempts < 400:
        attempts += 1
        px = random.randint(DESK_RECT.left + 80, DESK_RECT.right - 80)
        py = random.randint(DESK_RECT.top + 60, DESK_RECT.bottom - 60)
        if not far_from_spawns(px, py, 85):
            continue
        if all(math.hypot(px - h["pos"][0], py - h["pos"][1]) >= 115 for h in hazards):
            scale_roll = random.choice(["small", "medium", "large"])
            if scale_roll == "small":
                rx, ry = random.randint(20, 26), random.randint(15, 20)
            elif scale_roll == "medium":
                rx, ry = random.randint(32, 42), random.randint(24, 30)
            else:
                rx, ry = random.randint(46, 56), random.randint(32, 40)
            hazards.append({
                "kind": "patch",
                "pos": (px, py),
                "rx": rx,
                "ry": ry,
                "angle": random.uniform(0, math.pi),
            })

    return hazards

WORN_HAZARDS = generate_worn_hazards()

def build_space():
    space = pymunk.Space()
    space.gravity = (0, 0)
    space.damping = 0.99
    space.collision_bias = pow(1.0 - 0.25, 60.0)
    return space

def setup_fresh_round(p1_spec, p2_spec):
    space = build_space()
    p1 = create_pen(space, P1_SPAWN[0], P1_SPAWN[1], -math.pi / 2, p1_spec, P1_THEME, "Player 1", cap_on=True)
    p2 = create_pen(space, P2_SPAWN[0], P2_SPAWN[1], -math.pi / 2, p2_spec, P2_THEME, get_p2_name(), cap_on=True)
    return space, [p1, p2]

def setup_koth_round(winner_idx, winner_pen_data, new_loser_spec):
    space = build_space()
    wx, wy = winner_pen_data["pos"]
    w_angle = winner_pen_data["angle"]
    w_spec = winner_pen_data["spec"]
    w_cap = winner_pen_data.get("cap_on", True)
    p2_lbl = get_p2_name()

    if winner_idx == 0:
        p1 = create_pen(space, wx, wy, w_angle, w_spec, P1_THEME, "Player 1", cap_on=w_cap)
        p2 = create_pen(space, P2_SPAWN[0], P2_SPAWN[1], -math.pi / 2, new_loser_spec, P2_THEME, p2_lbl, cap_on=True)
    else:
        p1 = create_pen(space, P1_SPAWN[0], P1_SPAWN[1], -math.pi / 2, new_loser_spec, P1_THEME, "Player 1", cap_on=True)
        p2 = create_pen(space, wx, wy, w_angle, w_spec, P2_THEME, p2_lbl, cap_on=w_cap)

    return space, [p1, p2]

def render_pen_surface(spec, primary_color, accent_color, scale=1.0, cap_on=True):
    raw_l, raw_t, _, _, _, _, _ = get_effective_specs(spec, cap_on)
    l = max(12, int(raw_l * scale))
    t = max(4, int(raw_t * scale))
    surf = pygame.Surface((l, t), pygame.SRCALPHA)
    pid = spec["id"]

    if pid == "045_fine":
        if cap_on:
            cap_w = int(26 * scale)
            pygame.draw.rect(surf, primary_color, (0, 1, max(4, l - cap_w), max(2, t - 2)), border_radius=3)
            pygame.draw.rect(surf, accent_color, (int(12 * scale), t // 2 - 1, max(2, l - cap_w - int(16 * scale)), 2))
            pygame.draw.rect(surf, (235, 240, 248), (l - cap_w, 0, cap_w, t), border_radius=3)
            pygame.draw.rect(surf, primary_color, (l - cap_w + 2, 1, max(4, cap_w - 6), 2))
        else:
            tip_w = int(16 * scale)
            pygame.draw.rect(surf, primary_color, (0, 1, max(4, l - tip_w), max(2, t - 2)), border_radius=3)
            pygame.draw.rect(surf, accent_color, (int(12 * scale), t // 2 - 1, max(2, l - tip_w - int(16 * scale)), 2))
            pygame.draw.polygon(surf, (220, 225, 232), [(l - tip_w, 1), (l, t // 2), (l - tip_w, t - 1)])

    elif pid == "perm_marker":
        if cap_on:
            cap_w = int(28 * scale)
            pygame.draw.rect(surf, primary_color, (0, 0, max(4, l - cap_w - 1), t), border_radius=3)
            pygame.draw.rect(surf, (225, 190, 75), (l - cap_w - int(5 * scale), 0, max(2, int(5 * scale)), t))
            pygame.draw.rect(surf, (215, 220, 228), (l - cap_w, 0, cap_w, t), border_radius=3)
            pygame.draw.rect(surf, (225, 190, 75), (l - int(22 * scale), 1, max(4, int(16 * scale)), max(2, int(3 * scale))))
        else:
            nib_w = int(16 * scale)
            pygame.draw.rect(surf, primary_color, (0, 0, max(4, l - nib_w), t), border_radius=3)
            pygame.draw.rect(surf, (225, 190, 75), (l - nib_w - int(5 * scale), 0, max(2, int(5 * scale)), t))
            pygame.draw.polygon(surf, (30, 32, 38), [(l - nib_w, 3), (l, 2), (l, t - 3), (l - nib_w, t - 3)])

    elif pid == "rubber_grip":
        grip_w = int(26 * scale)
        if cap_on:
            cap_w = int(22 * scale)
            pygame.draw.rect(surf, primary_color, (0, 0, max(4, l - cap_w), t), border_radius=4)
            pygame.draw.rect(surf, (220, 220, 220), (0, max(1, int(3 * scale)), max(3, int(8 * scale)), max(2, t - int(6 * scale))), border_radius=2)
            grip_x = l - cap_w - grip_w
            pygame.draw.rect(surf, (35, 38, 44), (grip_x, 0, grip_w, t))
            pygame.draw.rect(surf, (225, 230, 238), (l - cap_w, 1, cap_w, max(2, t - 2)), border_radius=3)
        else:
            tip_w = int(16 * scale)
            pygame.draw.rect(surf, primary_color, (0, 0, max(4, l - tip_w), t), border_radius=4)
            grip_x = l - tip_w - grip_w
            pygame.draw.rect(surf, (35, 38, 44), (grip_x, 0, grip_w, t))
            if scale >= 0.8:
                for gx in range(grip_x + 4, grip_x + grip_w - 2, 6):
                    pygame.draw.line(surf, accent_color, (gx, 1), (gx, t - 2), 2)
            pygame.draw.polygon(surf, (235, 238, 245), [(l - tip_w, 1), (l, t // 2), (l - tip_w, t - 1)])

    elif pid == "highlighter":
        if cap_on:
            cap_w = int(24 * scale)
            pygame.draw.rect(surf, primary_color, (0, 0, max(4, l - cap_w), t), border_radius=5)
            pygame.draw.rect(surf, accent_color, (int(8 * scale), max(2, int(4 * scale)), max(4, l - int(38 * scale)), max(2, t - int(8 * scale))), border_radius=3)
            pygame.draw.rect(surf, (240, 240, 240), (l - cap_w, 1, cap_w, max(2, t - 2)), border_radius=4)
        else:
            nib_w = int(14 * scale)
            pygame.draw.rect(surf, primary_color, (0, 0, max(4, l - nib_w), t), border_radius=5)
            pygame.draw.rect(surf, accent_color, (int(8 * scale), max(2, int(4 * scale)), max(4, l - nib_w - int(14 * scale)), max(2, t - int(8 * scale))), border_radius=3)
            pygame.draw.polygon(surf, accent_color, [(l - nib_w, 3), (l, 2), (l, t - 4), (l - nib_w, t - 3)])

    elif pid == "pencil":
        eraser_w = int(14 * scale)
        ferrule_w = int(8 * scale)
        tip_w = int(22 * scale)
        pygame.draw.rect(surf, (228, 120, 135), (0, 1, eraser_w, max(2, t - 2)), border_radius=2)
        pygame.draw.rect(surf, (200, 205, 212), (eraser_w, 0, ferrule_w, t))
        body_x = eraser_w + ferrule_w
        body_w = max(4, l - body_x - tip_w)
        pygame.draw.rect(surf, (235, 185, 55), (body_x, 0, body_w, t))
        pygame.draw.line(surf, primary_color, (body_x, t // 2), (body_x + body_w, t // 2), 2)
        pygame.draw.polygon(surf, (235, 205, 165), [(l - tip_w, 0), (l, t // 2), (l - tip_w, t)])
        pygame.draw.polygon(surf, (45, 48, 55), [(l - int(8 * scale), int(t * 0.32)), (l, t // 2), (l - int(8 * scale), int(t * 0.68))])

    elif pid == "chalk":
        pygame.draw.rect(surf, (242, 244, 248), (0, 0, l, t), border_radius=4)
        pygame.draw.rect(surf, primary_color, (int(l * 0.25), 0, max(4, int(l * 0.16)), t))
        pygame.draw.rect(surf, (215, 220, 228), (0, 0, l, t), width=1, border_radius=4)

    elif pid == "eraser":
        pygame.draw.rect(surf, (244, 245, 248), (0, 0, l, t), border_radius=5)
        sleeve_x = int(l * 0.22)
        sleeve_w = int(l * 0.56)
        pygame.draw.rect(surf, primary_color, (sleeve_x, 0, sleeve_w, t))
        pygame.draw.rect(surf, accent_color, (sleeve_x + 3, 3, max(4, sleeve_w - 6), max(2, t - 6)), width=2)

    return surf

def draw_pen(surface, pen, boosted=False, fall_scale=1.0):
    body = pen["body"]
    if boosted and fall_scale >= 0.99:
        glow_r = int(pen["eff_length"] * 0.55)
        pygame.draw.circle(surface, (255, 220, 75), (int(body.position.x), int(body.position.y)), glow_r, width=3)
    surf = render_pen_surface(pen["spec"], pen["theme"]["primary"], pen["theme"]["accent"], scale=fall_scale, cap_on=pen["cap_on"])
    rotated = pygame.transform.rotate(surf, -math.degrees(body.angle))
    rect = rotated.get_rect(center=(body.position.x, body.position.y))
    surface.blit(rotated, rect.topleft)

def pens_stopped(pens):
    for p in pens:
        if p["body"].velocity.length > 8 or abs(p["body"].angular_velocity) > 0.22:
            return False
    return True

def is_off_desk(pen):
    x, y = pen["body"].position
    return not DESK_RECT.collidepoint(x, y)

def get_grab_point(pen, touch_pos):
    """Slightly wider grab tolerance on mobile so thumbs grab pens effortlessly."""
    body = pen["body"]
    eff_l = pen["eff_length"]
    eff_t = pen["eff_thickness"]
    local_pt = body.world_to_local(touch_pos)
    half_len = eff_l / 2 + 24
    half_thick = eff_t / 2 + 28
    if abs(local_pt.x) <= half_len and abs(local_pt.y) <= half_thick:
        if abs(local_pt.x) < 22:
            return pymunk.Vec2d(0, 0)
        clamped_x = max(-eff_l / 2 + 6, min(eff_l / 2 - 6, local_pt.x))
        return pymunk.Vec2d(clamped_x, 0)
    return None

def try_safe_rotate_pen(pen, other_pen, delta_rad):
    body = pen["body"]
    old_angle = body.angle
    body.angle = old_angle + delta_rad

    if pens_touching(pen, other_pen, padding=1.0):
        body.angle = old_angle
        return False

    half_l = pen["eff_length"] * 0.45
    tip1 = body.local_to_world((half_l, 0))
    tip2 = body.local_to_world((-half_l, 0))
    if not DESK_RECT.collidepoint(tip1.x, tip1.y) or not DESK_RECT.collidepoint(tip2.x, tip2.y):
        body.angle = old_angle
        return False

    return True

def step_desk_physics(sim_space, sim_pens, surf_spec, dt):
    for p in sim_pens:
        body = p["body"]
        spec = p["spec"]
        is_rubber_grip = (spec["id"] == "rubber_grip")
        speed = body.velocity.length

        stop_thresh = 34.0 if is_rubber_grip else 24.0
        if surf_spec["slope_pull"] > 0 and speed > stop_thresh:
            slope_factor = 0.55 if is_rubber_grip else 1.0
            body.velocity = (body.velocity.x, body.velocity.y + (surf_spec["slope_pull"] * slope_factor) * dt)

        _, _, _, _, _, native_drag, _ = get_effective_specs(spec, p["cap_on"])
        base_drag = min(0.992, max(0.84, native_drag + surf_spec["drag_offset"]))

        if surf_spec["id"] == "worn" and speed > 8:
            for h in WORN_HAZARDS:
                if point_in_oriented_ellipse((body.position.x, body.position.y), h):
                    if h["kind"] == "deadzone":
                        base_drag -= 0.068
                        body.angular_velocity *= 0.85
                    elif h["kind"] == "streak":
                        base_drag -= 0.016
                        twist = 0.025 if is_rubber_grip else 0.062
                        body.angular_velocity += twist * (1 if math.sin(h["angle"]) >= 0 else -1)
                    else:
                        base_drag -= 0.015
                        jolt = 0.014 if is_rubber_grip else 0.032
                        body.angular_velocity += jolt * (1 if (int(h["pos"][0]) % 2 == 0) else -1)
                    break

        sub_drag = max(0.80, base_drag) ** (1.0 / PHYSICS_SUBSTEPS)
        body.velocity *= sub_drag
        body.angular_velocity *= sub_drag

        if body.velocity.length < 8.5 and abs(body.angular_velocity) < 0.22:
            body.velocity = (0, 0)
            body.angular_velocity = 0

    sim_space.step(dt)

def execute_flick(pen_idx, grab_pt, target_pull_vec):
    global pen_touched_this_shot, shot_count_in_round, active_boost_player, boost_notice, turn
    body = pens[pen_idx]["body"]
    spec = pens[pen_idx]["spec"]
    anchor_world = body.local_to_world(grab_pt)

    dx, dy = target_pull_vec
    pull_dist = math.hypot(dx, dy)
    if pull_dist <= 12:
        return False

    is_boosted = (game_mode == "tactical" and active_boost_player == pen_idx)
    _, _, _, _, power_mult, _, _ = get_effective_specs(spec, pens[pen_idx]["cap_on"])

    if is_boosted:
        if spec["id"] == "045_fine":
            power_mult *= 1.45
        elif spec["id"] == "perm_marker":
            power_mult *= 1.50
            body.mass *= 1.45
        elif spec["id"] == "highlighter":
            power_mult *= 1.25
            pens[pen_idx]["shape"].elasticity = 1.15
            body.moment *= 0.65

    power = min(pull_dist, MAX_PULL) * power_mult
    angle = math.atan2(dy, dx)
    impulse = (math.cos(angle) * power, math.sin(angle) * power)
    body.apply_impulse_at_world_point(impulse, anchor_world)

    pen_touched_this_shot = False
    shot_count_in_round += 1
    if is_boosted:
        active_boost_player = None
        boost_notice = ""

    turn = 1 - turn
    return True

# --- CPU AI Logic ---
def simulate_cpu_shot(grab_pt, pull_vec, cap_on_state):
    surf_spec = SURFACES[selected_surface_idx]
    sim_space = build_space()

    p0_src = pens[0]
    p1_src = pens[1]

    sim_p0 = create_pen(
        sim_space,
        p0_src["body"].position.x,
        p0_src["body"].position.y,
        p0_src["body"].angle,
        p0_src["spec"],
        P1_THEME,
        "P1",
        cap_on=p0_src["cap_on"],
    )
    sim_p1 = create_pen(
        sim_space,
        p1_src["body"].position.x,
        p1_src["body"].position.y,
        p1_src["body"].angle,
        p1_src["spec"],
        P2_THEME,
        "CPU",
        cap_on=cap_on_state,
    )
    sim_pens = [sim_p0, sim_p1]

    is_boosted = (game_mode == "tactical" and active_boost_player == 1)
    _, _, _, _, power_mult, _, _ = get_effective_specs(sim_p1["spec"], cap_on_state)

    if is_boosted:
        sid = sim_p1["spec"]["id"]
        if sid == "045_fine":
            power_mult *= 1.45
        elif sid == "perm_marker":
            power_mult *= 1.50
            sim_p1["body"].mass *= 1.45
        elif sid == "highlighter":
            power_mult *= 1.25
            sim_p1["shape"].elasticity = 1.15
            sim_p1["body"].moment *= 0.65

    dx, dy = pull_vec
    pull_dist = min(MAX_PULL, math.hypot(dx, dy))
    angle = math.atan2(dy, dx)
    power = pull_dist * power_mult
    anchor_world = sim_p1["body"].local_to_world(grab_pt)
    sim_p1["body"].apply_impulse_at_world_point((math.cos(angle) * power, math.sin(angle) * power), anchor_world)

    touched = False
    p0_out = False
    p1_out = False

    sim_substeps = 2
    sim_dt = 1.0 / (60.0 * sim_substeps)
    for _ in range(130):
        for _ in range(sim_substeps):
            step_desk_physics(sim_space, sim_pens, surf_spec, sim_dt)
            if not touched and pens_touching(sim_p0, sim_p1, padding=2.0):
                touched = True

        if not DESK_RECT.collidepoint(sim_p0["body"].position.x, sim_p0["body"].position.y):
            p0_out = True
        if not DESK_RECT.collidepoint(sim_p1["body"].position.x, sim_p1["body"].position.y):
            p1_out = True
        if p0_out or p1_out:
            break
        if pens_stopped(sim_pens):
            break

    if p1_out and not p0_out:
        return -2000.0
    if p1_out and p0_out:
        return -450.0
    if p0_out and not p1_out:
        return 1500.0

    score = 0.0
    if touched:
        score += 220.0
    elif game_mode == "tactical" and shot_count_in_round >= 1:
        score -= 320.0

    p0x, p0y = sim_p0["body"].position.x, sim_p0["body"].position.y
    p0_edge_margin = min(
        p0x - DESK_RECT.left,
        DESK_RECT.right - p0x,
        p0y - DESK_RECT.top,
        DESK_RECT.bottom - p0y,
    )
    score += max(0.0, (195.0 - p0_edge_margin)) * 1.65

    p1x, p1y = sim_p1["body"].position.x, sim_p1["body"].position.y
    p1_edge_margin = min(
        p1x - DESK_RECT.left,
        DESK_RECT.right - p1x,
        p1y - DESK_RECT.top,
        DESK_RECT.bottom - p1y,
    )
    if p1_edge_margin < 48.0:
        score -= (48.0 - p1_edge_margin) * 4.5

    if surf_spec["id"] == "worn":
        for h in WORN_HAZARDS:
            if h["kind"] == "deadzone" and point_in_oriented_ellipse((p1x, p1y), h):
                score -= 280.0

    final_dist = math.hypot(p0x - p1x, p0y - p1y)
    score -= final_dist * 0.12

    return score

def cpu_choose_item():
    is_fp = (game_mode == "freeplay")
    pool = list(range(len(ALL_ITEMS))) if is_fp else list(alive_pens[1])
    if not pool:
        return 0

    surf_id = SURFACES[selected_surface_idx]["id"]
    if opponent_mode == "topper":
        return random.choice(pool)

    weights = []
    for idx in pool:
        sid = ALL_ITEMS[idx]["id"]
        w = 1.0
        if surf_id in ("angled", "worn") and sid == "rubber_grip":
            w = 3.0 if opponent_mode == "backbencher" else 1.8
        elif surf_id == "laminated" and sid in ("rubber_grip", "perm_marker"):
            w = 2.4
        elif sid == "perm_marker":
            w = 2.0
        elif is_fp and sid in ("pencil", "eraser"):
            w = 1.7
        weights.append(w)

    return random.choices(pool, weights=weights, k=1)[0]

def cpu_plan_shot():
    cpu_pen = pens[1]
    hum_pen = pens[0]
    c_body = cpu_pen["body"]
    h_body = hum_pen["body"]
    spec = cpu_pen["spec"]

    if game_mode == "tactical" and active_boost_player == 1 and spec["id"] == "rubber_grip":
        for _ in range(12):
            ang_to_target = math.atan2(h_body.position.y - c_body.position.y, h_body.position.x - c_body.position.x)
            diff = (ang_to_target - c_body.angle + math.pi) % (2 * math.pi) - math.pi
            if abs(diff) < 0.12:
                break
            step = math.radians(6) if diff > 0 else -math.radians(6)
            if not try_safe_rotate_pen(cpu_pen, hum_pen, step):
                break

    if opponent_mode == "topper":
        grab_pt = pymunk.Vec2d(0, 0)
        anchor_world = c_body.local_to_world(grab_pt)
        dx = h_body.position.x - anchor_world.x
        dy = h_body.position.y - anchor_world.y
        dist = math.hypot(dx, dy)
        ang = math.atan2(dy, dx) + random.uniform(-0.24, 0.24)
        pull = min(MAX_PULL, max(50.0, dist * 0.52 * random.uniform(0.72, 1.15)))
        return grab_pt, (math.cos(ang) * pull, math.sin(ang) * pull), False

    cap_states_to_test = [cpu_pen["cap_on"]]
    if spec.get("has_cap", False) and not cpu_pen["cap_toggled_this_round"] and opponent_mode == "backbencher":
        cap_states_to_test.append(not cpu_pen["cap_on"])

    best_score = -999999.0
    best_plan = None

    hx, hy = h_body.position.x, h_body.position.y
    h_half = hum_pen["eff_length"] * 0.36
    h_tip1 = h_body.local_to_world((h_half, 0))
    h_tip2 = h_body.local_to_world((-h_half, 0))
    target_points = [(hx, hy), (h_tip1.x, h_tip1.y), (h_tip2.x, h_tip2.y)]

    if opponent_mode == "backbencher":
        grab_offsets = [0.0, -0.34, 0.34]
        power_candidates = [85.0, 125.0, 165.0, 200.0]
        slope_offsets = [0.0, -24.0] if SURFACES[selected_surface_idx]["slope_pull"] > 0 else [0.0]
    else:
        grab_offsets = [0.0, 0.26]
        power_candidates = [95.0, 145.0, 190.0]
        slope_offsets = [0.0]

    for cap_state in cap_states_to_test:
        eff_l, _, _, _, _, _, _ = get_effective_specs(spec, cap_state)
        for g_frac in grab_offsets:
            g_pt = pymunk.Vec2d(g_frac * eff_l, 0)
            anchor_w = c_body.local_to_world(g_pt)
            for tx, ty in target_points:
                for sy in slope_offsets:
                    base_ang = math.atan2((ty + sy) - anchor_w.y, tx - anchor_w.x)
                    for p_mag in power_candidates:
                        p_vec = (math.cos(base_ang) * p_mag, math.sin(base_ang) * p_mag)
                        sc = simulate_cpu_shot(g_pt, p_vec, cap_state)
                        if cap_state != cpu_pen["cap_on"]:
                            sc -= 25.0
                        if sc > best_score:
                            best_score = sc
                            best_plan = (g_pt, p_vec, cap_state != cpu_pen["cap_on"])

    g_pt, p_vec, do_cap = best_plan
    noise_ang = random.uniform(-0.08, 0.08) if opponent_mode == "regular" else random.uniform(-0.018, 0.018)
    noise_pow = random.uniform(0.90, 1.08) if opponent_mode == "regular" else random.uniform(0.98, 1.02)
    ang = math.atan2(p_vec[1], p_vec[0]) + noise_ang
    mag = min(MAX_PULL, max(40.0, math.hypot(p_vec[0], p_vec[1]) * noise_pow))

    return g_pt, (math.cos(ang) * mag, math.sin(ang) * mag), do_cap

def draw_dotted_line(surface, color, start, end, spacing=12):
    dx = end[0] - start[0]
    dy = end[1] - start[1]
    dist = math.hypot(dx, dy)
    if dist == 0:
        return
    steps = int(dist // spacing)
    for i in range(1, steps + 1):
        t = i / steps
        x = int(start[0] + dx * t)
        y = int(start[1] + dy * t)
        radius = max(2, int(5 * (1 - t * 0.5)))
        pygame.draw.circle(surface, color, (x, y), radius)

def draw_rotated_ellipse(surface, fill_color, border_color, pos, rx, ry, angle_rad):
    w, h = rx * 2 + 4, ry * 2 + 4
    temp = pygame.Surface((w, h), pygame.SRCALPHA)
    rect = pygame.Rect(2, 2, rx * 2, ry * 2)
    pygame.draw.ellipse(temp, fill_color, rect)
    if border_color:
        pygame.draw.ellipse(temp, border_color, rect, width=2)
    rot = pygame.transform.rotate(temp, -math.degrees(angle_rad))
    surface.blit(rot, rot.get_rect(center=pos).topleft)

def draw_chalk_rect(surface, rect, color, width=2):
    tl = (rect.left, rect.top)
    tr = (rect.right, rect.top)
    br = (rect.right, rect.bottom)
    bl = (rect.left, rect.bottom)
    pygame.draw.line(surface, color, (tl[0] - 2, tl[1]), (tr[0] + 2, tr[1]), width)
    pygame.draw.line(surface, color, (bl[0] - 2, bl[1]), (br[0] + 2, br[1]), width)
    pygame.draw.line(surface, color, (tl[0], tl[1] - 2), (bl[0], bl[1] + 2), width)
    pygame.draw.line(surface, color, (tr[0], tr[1] - 2), (br[0], br[1] + 2), width)

def draw_wrapped_chalk_text(surface, text, font_obj, color, x, y, max_width, line_height=18):
    words = text.split(" ")
    lines = []
    current = ""
    for w in words:
        test = f"{current} {w}".strip()
        if font_obj.size(test)[0] <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = w
    if current:
        lines.append(current)

    for i, line in enumerate(lines):
        surf = font_obj.render(line, True, color)
        surface.blit(surf, (x, y + i * line_height))
    return len(lines) * line_height

def draw_blackboard_menu(surface, mouse_pos, mode_rects, opp_rects):
    surface.fill((36, 40, 48))

    board_outer = pygame.Rect(36, 22, WIDTH - 72, HEIGHT - 54)
    board_inner = board_outer.inflate(-26, -26)
    pygame.draw.rect(surface, (112, 76, 44), board_outer, border_radius=10)
    pygame.draw.rect(surface, (78, 50, 28), board_outer, width=4, border_radius=10)

    pygame.draw.rect(surface, (33, 44, 41), board_inner, border_radius=4)

    smudge_surf = pygame.Surface((board_inner.width, board_inner.height), pygame.SRCALPHA)
    pygame.draw.ellipse(smudge_surf, (255, 255, 255, 9), (90, 40, 320, 120))
    pygame.draw.ellipse(smudge_surf, (255, 255, 255, 7), (480, 210, 360, 160))
    pygame.draw.ellipse(smudge_surf, (255, 255, 255, 8), (180, 330, 290, 110))
    surface.blit(smudge_surf, board_inner.topleft)

    ledge = pygame.Rect(board_outer.x - 10, board_outer.bottom - 10, board_outer.width + 20, 18)
    pygame.draw.rect(surface, (128, 88, 52), ledge, border_radius=5)
    pygame.draw.rect(surface, (82, 54, 30), ledge, width=2, border_radius=5)
    pygame.draw.rect(surface, (242, 244, 246), (ledge.x + 140, ledge.y - 6, 38, 7), border_radius=2)
    pygame.draw.rect(surface, (165, 120, 75), (ledge.right - 220, ledge.y - 12, 74, 8), border_radius=2)
    pygame.draw.rect(surface, (65, 70, 75), (ledge.right - 220, ledge.y - 5, 74, 6))

    chalk_white = (242, 244, 240)
    chalk_dim = (195, 205, 200)
    hdr = chalk_title_font.render("PEN FIGHT", True, chalk_white)
    hdr_rect = hdr.get_rect(center=(WIDTH // 2, 74))
    surface.blit(hdr, hdr_rect)
    pygame.draw.line(surface, chalk_white, (hdr_rect.left - 18, hdr_rect.bottom + 1), (hdr_rect.right + 18, hdr_rect.bottom + 3), 3)

    sub = chalk_sub_font.render("~ Tap Opponent Below, Then Tap a Game Mode ~", True, chalk_dim)
    surface.blit(sub, sub.get_rect(center=(WIDTH // 2, 120)))

    for i, m in enumerate(MODES):
        rect = mode_rects[i]
        hovered = rect.collidepoint(mouse_pos)
        accent = m["chalk_accent"]

        if hovered:
            hl = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
            hl.fill((255, 255, 255, 18))
            surface.blit(hl, rect.topleft)

        draw_chalk_rect(surface, rect, accent if hovered else chalk_dim, width=3 if hovered else 2)

        badge = chalk_body_font.render(f"({i + 1})", True, chalk_dim)
        surface.blit(badge, (rect.x + 12, rect.y + 8))

        t_surf = chalk_card_title.render(m["title"], True, chalk_white)
        tag_surf = chalk_body_font.render(m["tag"], True, accent)
        surface.blit(t_surf, t_surf.get_rect(center=(rect.centerx, rect.y + 44)))
        surface.blit(tag_surf, tag_surf.get_rect(center=(rect.centerx, rect.y + 70)))

        pygame.draw.line(surface, chalk_dim, (rect.x + 16, rect.y + 90), (rect.right - 16, rect.y + 90), 1)

        cur_y = rect.y + 102
        inner_max_w = rect.width - 28
        for line in m["desc"]:
            used_h = draw_wrapped_chalk_text(surface, line, chalk_body_font, chalk_white, rect.x + 14, cur_y, inner_max_w, line_height=18)
            cur_y += used_h + 6

        btn = pygame.Rect(rect.x + 32, rect.bottom - 44, rect.width - 64, 32)
        draw_chalk_rect(surface, btn, accent if hovered else chalk_dim, width=2)
        play_lbl = chalk_sub_font.render("PLAY", True, accent if hovered else chalk_white)
        surface.blit(play_lbl, play_lbl.get_rect(center=btn.center))

    opp_hdr = chalk_body_font.render("OPPONENT:", True, chalk_dim)
    surface.blit(opp_hdr, (opp_rects[0].x - opp_hdr.get_width() - 12, opp_rects[0].centery - opp_hdr.get_height() // 2))

    for i, opt in enumerate(OPPONENT_OPTIONS):
        r = opp_rects[i]
        is_sel = (opponent_mode == opt["id"])
        hov = r.collidepoint(mouse_pos)
        col = opt["color"]

        if is_sel or hov:
            hl = pygame.Surface((r.width, r.height), pygame.SRCALPHA)
            hl.fill((255, 255, 255, 26 if is_sel else 14))
            surface.blit(hl, r.topleft)

        draw_chalk_rect(surface, r, col if is_sel else (chalk_white if hov else chalk_dim), width=3 if is_sel else 1)

        lbl_s = chalk_pill_font.render(opt["label"], True, col if is_sel else chalk_white)
        sub_s = chalk_body_font.render(opt["sub"], True, chalk_dim)
        surface.blit(lbl_s, lbl_s.get_rect(center=(r.centerx, r.y + 16)))
        surface.blit(sub_s, sub_s.get_rect(center=(r.centerx, r.y + 35)))

def draw_desk(surface, surf_spec, chalk_trails):
    pygame.draw.rect(surface, (16, 18, 24), DESK_RECT.move(10, 14), border_radius=10)
    pygame.draw.rect(surface, surf_spec["desk_color"], DESK_RECT, border_radius=10)

    sid = surf_spec["id"]
    if sid in ("fresh", "worn", "angled"):
        for gy in range(DESK_RECT.top + 35, DESK_RECT.bottom - 20, 48):
            pygame.draw.line(surface, surf_spec["grain_color"], (DESK_RECT.left + 12, gy), (DESK_RECT.right - 12, gy), 2)

    if sid == "laminated":
        pygame.draw.line(surface, (74, 92, 108), (DESK_RECT.left + 45, DESK_RECT.top + 16), (DESK_RECT.left + 185, DESK_RECT.bottom - 16), 8)
        pygame.draw.line(surface, (74, 92, 108), (DESK_RECT.left + 225, DESK_RECT.top + 16), (DESK_RECT.left + 365, DESK_RECT.bottom - 16), 3)

    elif sid == "worn":
        for h in WORN_HAZARDS:
            if h["kind"] == "deadzone":
                draw_rotated_ellipse(surface, (96, 70, 48), (74, 52, 34), h["pos"], h["rx"], h["ry"], h["angle"])
                draw_rotated_ellipse(surface, (82, 58, 38), None, h["pos"], int(h["rx"] * 0.72), int(h["ry"] * 0.72), h["angle"])
                dz_lbl = small_font.render("DEAD ZONE", True, (145, 115, 85))
                surface.blit(dz_lbl, dz_lbl.get_rect(center=h["pos"]))
            elif h["kind"] == "streak":
                draw_rotated_ellipse(surface, (124, 94, 66), (108, 80, 54), h["pos"], h["rx"], h["ry"], h["angle"])
            else:
                draw_rotated_ellipse(surface, (134, 104, 74), (118, 90, 62), h["pos"], h["rx"], h["ry"], h["angle"])

    elif sid == "angled":
        for cx in (DESK_RECT.left + 90, DESK_RECT.centerx, DESK_RECT.right - 90):
            for cy in (DESK_RECT.top + 70, DESK_RECT.centery, DESK_RECT.bottom - 75):
                pygame.draw.lines(surface, (158, 118, 80), False, [(cx - 12, cy - 5), (cx, cy + 6), (cx + 12, cy - 5)], 2)

    for dot in chalk_trails:
        pygame.draw.circle(surface, (242, 244, 248), (int(dot[0]), int(dot[1])), 3)

    pygame.draw.rect(surface, surf_spec["border_color"], DESK_RECT, width=6, border_radius=10)

def draw_pencil_boxes(surface, mouse_pos, picking_player, open_box_player):
    hovered_spec = None
    is_fp = (game_mode == "freeplay")

    for p_idx, theme in [(0, P1_THEME), (1, P2_THEME)]:
        box = get_box_rect(p_idx)
        is_picker = (picking_player == p_idx)
        is_open = (open_box_player == p_idx)
        p_name = "Player 1" if p_idx == 0 else get_p2_name()

        if is_fp:
            needed = (best_of_target // 2) + 1
            hdr_txt = f"{p_name}  •  Wins: {series_wins[p_idx]}/{needed}"
        else:
            hdr_txt = f"{p_name}  •  Pens: {len(alive_pens[p_idx])}/4"
        hdr_s = font.render(hdr_txt, True, theme["accent"])
        if p_idx == 0:
            surface.blit(hdr_s, (box.x, 20))
        else:
            surface.blit(hdr_s, (box.right - hdr_s.get_width(), 20))

        pygame.draw.rect(surface, theme["box_bg"], box, border_radius=8)
        border_c = (255, 235, 110) if (is_picker or is_open) else theme["primary"]
        pygame.draw.rect(surface, border_c, box, width=3 if is_picker else 2, border_radius=8)

        clasp_x = box.right - 14 if p_idx == 0 else box.x + 6
        pygame.draw.rect(surface, (210, 215, 225), (clasp_x, box.centery - 6, 8, 12), border_radius=2)

        lbl_str = "TAP TO OPEN BOX" if (is_picker and not is_open) else ("PICK ITEM BELOW" if is_open else "PENCIL BOX")
        lbl_x = box.x + 10 if p_idx == 0 else box.x + 20
        lbl_s = small_font.render(lbl_str, True, (255, 245, 180) if is_picker else (225, 230, 240))
        surface.blit(lbl_s, (lbl_x, box.y + 7))

        for pip_i in range(4):
            alive = pip_i in alive_pens[p_idx]
            px = lbl_x + pip_i * 22
            py = box.y + 29
            pip_col = theme["accent"] if alive else (75, 80, 92)
            pygame.draw.rect(surface, pip_col, (px, py, 16, 6), border_radius=2)

        if is_open:
            tray = get_dropdown_tray_rect(p_idx, is_fp)
            pygame.draw.rect(surface, (24, 27, 35), tray, border_radius=10)
            pygame.draw.rect(surface, theme["primary"], tray, width=2, border_radius=10)

            if is_fp:
                col_w = (tray.width - 15) // 2
                c1_lbl = small_font.render("PENS", True, (165, 175, 195))
                c2_lbl = small_font.render("SPECIAL ITEMS", True, (255, 220, 110))
                surface.blit(c1_lbl, c1_lbl.get_rect(center=(tray.x + 5 + col_w // 2, tray.y + 12)))
                surface.blit(c2_lbl, c2_lbl.get_rect(center=(tray.x + 10 + col_w + col_w // 2, tray.y + 12)))

            available_items = ALL_ITEMS if is_fp else CORE_PENS
            for item_i, spec in enumerate(available_items):
                slot = get_dropdown_slot_rect(p_idx, item_i, is_fp)
                is_alive = is_fp or (item_i in alive_pens[p_idx])
                s_hover = is_alive and slot.collidepoint(mouse_pos)

                slot_bg = (58, 65, 82) if s_hover else ((40, 44, 56) if is_alive else (30, 32, 39))
                pygame.draw.rect(surface, slot_bg, slot, border_radius=7)
                if s_hover:
                    pygame.draw.rect(surface, (255, 235, 110), slot, width=2, border_radius=7)

                if is_alive:
                    p_surf = render_pen_surface(spec, theme["primary"], theme["accent"], scale=0.82, cap_on=True)
                    surface.blit(p_surf, p_surf.get_rect(center=(slot.centerx, slot.y + 19)))
                    n_s = small_font.render(spec["name"], True, (240, 244, 250))
                    surface.blit(n_s, n_s.get_rect(center=(slot.centerx, slot.bottom - 12)))
                    if s_hover:
                        hovered_spec = spec
                else:
                    p_surf = render_pen_surface(spec, (80, 84, 94), (105, 110, 120), scale=0.80, cap_on=True)
                    surface.blit(p_surf, p_surf.get_rect(center=(slot.centerx, slot.y + 19)))
                    n_s = small_font.render(f"{spec['name']} (OUT)", True, (130, 110, 115))
                    surface.blit(n_s, n_s.get_rect(center=(slot.centerx, slot.bottom - 12)))

    return hovered_spec

def draw_touch_button(surface, rect, text, bg_color, border_color, text_color=(245, 245, 250)):
    pygame.draw.rect(surface, bg_color, rect, border_radius=8)
    pygame.draw.rect(surface, border_color, rect, width=2, border_radius=8)
    lbl = med_font.render(text, True, text_color)
    surface.blit(lbl, lbl.get_rect(center=rect.center))

# --- Game & Match State ---
screen_state = "MENU"
game_mode = "freeplay"
opponent_mode = "2p"
selected_surface_idx = 0
best_of_target = 3
series_wins = [0, 0]

alive_pens = [[0, 1, 2, 3], [0, 1, 2, 3]]
selected_idx = [None, None]
select_queue = []
open_box_player = None
koth_holder = None

space = None
pens = []
chalk_trails = []
turn = 0
dragging = False
grab_local = pymunk.Vec2d(0, 0)

cpu_think_timer = 0
cpu_planned_shot = None

falling_timer = 0
out_flags = [False, False]
round_banner = None
match_winner = None

shot_count_in_round = 0
pen_touched_this_shot = False
active_boost_player = None
boost_notice = ""

def is_cpu_turn():
    return opponent_mode != "2p" and turn == 1

def enter_mode_setup(mode_id):
    global game_mode, selected_surface_idx, best_of_target, screen_state
    game_mode = mode_id
    selected_surface_idx = 0
    best_of_target = 3
    screen_state = "SETUP"

def begin_match():
    global alive_pens, selected_idx, select_queue, open_box_player, koth_holder
    global series_wins, round_banner, match_winner, pens, chalk_trails, active_boost_player, boost_notice, screen_state, WORN_HAZARDS, falling_timer, out_flags, cpu_think_timer, cpu_planned_shot
    WORN_HAZARDS = generate_worn_hazards()
    alive_pens = [[0, 1, 2, 3], [0, 1, 2, 3]]
    selected_idx = [None, None]
    select_queue = [0, 1]
    open_box_player = None
    koth_holder = None
    series_wins = [0, 0]
    round_banner = None
    match_winner = None
    pens = []
    chalk_trails = []
    falling_timer = 0
    out_flags = [False, False]
    active_boost_player = None
    boost_notice = ""
    cpu_think_timer = 0
    cpu_planned_shot = None
    screen_state = "SELECT"

def launch_round():
    global space, pens, chalk_trails, turn, dragging, round_banner, screen_state
    global shot_count_in_round, pen_touched_this_shot, active_boost_player, boost_notice, open_box_player, falling_timer, out_flags, cpu_think_timer, cpu_planned_shot

    p1_spec = ALL_ITEMS[selected_idx[0]]
    p2_spec = ALL_ITEMS[selected_idx[1]]

    if game_mode == "knockout" and koth_holder is not None:
        w_idx = koth_holder["player"]
        loser_spec = p2_spec if w_idx == 0 else p1_spec
        space, pens = setup_koth_round(w_idx, koth_holder, loser_spec)
        turn = 1 - w_idx
    else:
        space, pens = setup_fresh_round(p1_spec, p2_spec)
        turn = 0

    chalk_trails = []
    shot_count_in_round = 0
    pen_touched_this_shot = False
    active_boost_player = None
    boost_notice = ""
    open_box_player = None
    dragging = False
    round_banner = None
    falling_timer = 0
    out_flags = [False, False]
    cpu_think_timer = 0
    cpu_planned_shot = None
    screen_state = "PLAY"

def handle_pen_pick(item_idx):
    global select_queue, open_box_player
    if not select_queue:
        return
    picker = select_queue[0]
    is_fp = (game_mode == "freeplay")
    max_items = len(ALL_ITEMS) if is_fp else len(CORE_PENS)
    if item_idx < 0 or item_idx >= max_items:
        return
    if not is_fp and item_idx not in alive_pens[picker]:
        return

    selected_idx[picker] = item_idx
    select_queue.pop(0)
    open_box_player = None

    if select_queue and select_queue[0] == 1 and opponent_mode != "2p":
        cpu_idx = cpu_choose_item()
        selected_idx[1] = cpu_idx
        select_queue.pop(0)

    if not select_queue:
        launch_round()

def resolve_round_outcome():
    global koth_holder, match_winner, round_banner, select_queue, open_box_player, screen_state
    p1_out, p2_out = out_flags
    open_box_player = None
    p2_lbl = get_p2_name()

    if p1_out and p2_out:
        if game_mode == "freeplay":
            round_banner = "Double Ring-Out! Round Draw!"
            select_queue = [0, 1]
            screen_state = "SELECT"
        else:
            for idx in (0, 1):
                lost_idx = selected_idx[idx]
                if lost_idx in alive_pens[idx]:
                    alive_pens[idx].remove(lost_idx)

            koth_holder = None
            p1_left = len(alive_pens[0])
            p2_left = len(alive_pens[1])

            if p1_left == 0 and p2_left == 0:
                match_winner = "Match Draw! Both Players Lost All 4 Pens!"
            elif p1_left == 0:
                match_winner = f"{p2_lbl} Wins the Match! (P1 Out of Pens)"
            elif p2_left == 0:
                match_winner = f"Player 1 Wins the Match! ({p2_lbl} Out of Pens)"
            else:
                round_banner = f"Double KO! Both Pens Eliminated ({p1_left} vs {p2_left} left)"
                select_queue = [0, 1]
                screen_state = "SELECT"
        return

    w_idx = 1 if p1_out else 0
    l_idx = 1 - w_idx

    if game_mode == "freeplay":
        series_wins[w_idx] += 1
        needed = (best_of_target // 2) + 1
        w_label = "Player 1" if w_idx == 0 else p2_lbl
        if series_wins[w_idx] >= needed:
            match_winner = f"{w_label} Wins the Best-of-{best_of_target} Series ({series_wins[0]}–{series_wins[1]})!"
        else:
            round_banner = f"{pens[w_idx]['name']} Won Last Round ({series_wins[0]}–{series_wins[1]})"
            select_queue = [0, 1]
            screen_state = "SELECT"
    else:
        lost_pen_idx = selected_idx[l_idx]
        if lost_pen_idx in alive_pens[l_idx]:
            alive_pens[l_idx].remove(lost_pen_idx)

        w_body = pens[w_idx]["body"]
        koth_holder = {
            "player": w_idx,
            "pos": (w_body.position.x, w_body.position.y),
            "angle": w_body.angle,
            "spec": pens[w_idx]["spec"],
            "cap_on": pens[w_idx]["cap_on"]
        }

        if len(alive_pens[l_idx]) == 0:
            w_label = "Player 1" if w_idx == 0 else p2_lbl
            match_winner = f"{w_label} Wins the Match! (All 4 Pens Eliminated)"
        else:
            rem = len(alive_pens[l_idx])
            l_label = "Player 1" if l_idx == 0 else p2_lbl
            round_banner = f"{pens[w_idx]['name']} Won Round! ({l_label}: {rem} pen{'s' if rem > 1 else ''} left)"
            if game_mode == "knockout":
                if l_idx == 1 and opponent_mode != "2p":
                    selected_idx[1] = cpu_choose_item()
                    launch_round()
                    return
                select_queue = [l_idx]
            else:
                select_queue = [0, 1]
            screen_state = "SELECT"

# Menu & Setup Rects
MODE_W, MODE_H = 294, 315
MODE_GAP = 18
MODE_START_X = (WIDTH - (MODE_W * 3 + MODE_GAP * 2)) // 2
MODE_RECTS = [pygame.Rect(MODE_START_X + i * (MODE_W + MODE_GAP), 156, MODE_W, MODE_H) for i in range(3)]

OPP_W, OPP_H = 186, 52
OPP_GAP = 14
OPP_START_X = (WIDTH - (OPP_W * 4 + OPP_GAP * 3)) // 2 + 36
OPP_RECTS = [pygame.Rect(OPP_START_X + i * (OPP_W + OPP_GAP), 502, OPP_W, OPP_H) for i in range(4)]

SURF_W, SURF_H = 215, 165
SURF_GAP = 18
SURF_START_X = (WIDTH - (SURF_W * 4 + SURF_GAP * 3)) // 2
SURF_RECTS = [pygame.Rect(SURF_START_X + i * (SURF_W + SURF_GAP), 175, SURF_W, SURF_H) for i in range(4)]

BO_W, BO_H = 110, 46
BO_GAP = 16
BO_START_X = (WIDTH - (BO_W * 5 + BO_GAP * 4)) // 2
BO_RECTS = [pygame.Rect(BO_START_X + i * (BO_W + BO_GAP), 415, BO_W, BO_H) for i in range(5)]

START_BTN_RECT = pygame.Rect(WIDTH // 2 - 140, 520, 280, 54)

async def main():
    global screen_state, opponent_mode, selected_surface_idx, best_of_target
    global open_box_player, dragging, grab_local, falling_timer, active_boost_player
    global boost_notice, cpu_think_timer, cpu_planned_shot, pen_touched_this_shot

    running = True
    while running:
        clock.tick(60)
        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                screen_state = "MENU"
                dragging = False

            elif screen_state == "MENU":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for i, r in enumerate(OPP_RECTS):
                        if r.collidepoint(mouse_pos):
                            opponent_mode = OPPONENT_OPTIONS[i]["id"]
                    for i, rect in enumerate(MODE_RECTS):
                        if rect.collidepoint(mouse_pos):
                            enter_mode_setup(MODES[i]["id"])
                            break

            elif screen_state == "SETUP":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if SETUP_BACK_RECT.collidepoint(mouse_pos):
                        screen_state = "MENU"
                    for i, r in enumerate(SURF_RECTS):
                        if r.collidepoint(mouse_pos):
                            selected_surface_idx = i
                    if game_mode == "freeplay":
                        for i, r in enumerate(BO_RECTS):
                            if r.collidepoint(mouse_pos):
                                best_of_target = SERIES_OPTIONS[i]
                    if START_BTN_RECT.collidepoint(mouse_pos):
                        begin_match()

            elif screen_state == "SELECT":
                picker = select_queue[0]
                if picker == 1 and opponent_mode != "2p":
                    continue
                is_fp = (game_mode == "freeplay")
                max_items = len(ALL_ITEMS) if is_fp else len(CORE_PENS)
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if MENU_BTN_RECT.collidepoint(mouse_pos):
                        screen_state = "MENU"
                    elif get_box_rect(picker).collidepoint(mouse_pos):
                        open_box_player = None if open_box_player == picker else picker
                    elif open_box_player == picker:
                        for item_i in range(max_items):
                            if get_dropdown_slot_rect(picker, item_i, is_fp).collidepoint(mouse_pos):
                                handle_pen_pick(item_i)
                                break

            elif screen_state == "PLAY":
                can_human_act = (
                    not is_cpu_turn()
                    and falling_timer == 0
                    and match_winner is None
                    and pens_stopped(pens)
                    and not dragging
                )

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if match_winner is not None:
                        if REPLAY_BTN_RECT.collidepoint(mouse_pos):
                            begin_match()
                        elif END_MENU_BTN_RECT.collidepoint(mouse_pos):
                            screen_state = "MENU"
                    elif MENU_BTN_RECT.collidepoint(mouse_pos):
                        screen_state = "MENU"
                        dragging = False
                    elif can_human_act:
                        # Touch Cap On/Off Button
                        if (
                            pens[turn]["spec"].get("has_cap", False)
                            and not pens[turn]["cap_toggled_this_round"]
                            and CAP_BTN_RECT.collidepoint(mouse_pos)
                        ):
                            toggle_pen_cap(space, pens[turn])
                        # Touch Rotate Buttons (Tactical Rubber Grip Boost)
                        elif (
                            game_mode == "tactical"
                            and active_boost_player == turn
                            and pens[turn]["spec"]["id"] == "rubber_grip"
                            and (ROT_LEFT_RECT.collidepoint(mouse_pos) or ROT_RIGHT_RECT.collidepoint(mouse_pos))
                        ):
                            delta = -math.radians(8) if ROT_LEFT_RECT.collidepoint(mouse_pos) else math.radians(8)
                            try_safe_rotate_pen(pens[turn], pens[1 - turn], delta)
                        else:
                            hit = get_grab_point(pens[turn], mouse_pos)
                            if hit is not None:
                                dragging = True
                                grab_local = hit

                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and dragging:
                    dragging = False
                    body = pens[turn]["body"]
                    anchor_world = body.local_to_world(grab_local)
                    dx = anchor_world.x - mouse_pos[0]
                    dy = anchor_world.y - mouse_pos[1]
                    execute_flick(turn, grab_local, (dx, dy))

        # ==========================================
        # RENDER: BLACKBOARD MAIN MENU
        # ==========================================
        if screen_state == "MENU":
            draw_blackboard_menu(screen, mouse_pos, MODE_RECTS, OPP_RECTS)

        # ==========================================
        # RENDER: PRE-MATCH SETUP
        # ==========================================
        elif screen_state == "SETUP":
            screen.fill(FLOOR_COLOR)
            draw_touch_button(screen, SETUP_BACK_RECT, "< MENU", CARD_BG, (95, 105, 125))

            m_title = next(m["title"] for m in MODES if m["id"] == game_mode)
            opp_title = next(o["label"] for o in OPPONENT_OPTIONS if o["id"] == opponent_mode)
            hdr = title_font.render(f"{m_title} ({opp_title})", True, (245, 245, 250))
            screen.blit(hdr, hdr.get_rect(center=(WIDTH // 2, 55)))

            s_lbl = font.render("1. Tap Desk Surface (Locked for entire match)", True, (200, 210, 225))
            screen.blit(s_lbl, s_lbl.get_rect(center=(WIDTH // 2, 128)))

            for i, surf in enumerate(SURFACES):
                r = SURF_RECTS[i]
                is_sel = (selected_surface_idx == i)
                hov = r.collidepoint(mouse_pos)
                pygame.draw.rect(screen, CARD_HOVER if (is_sel or hov) else CARD_BG, r, border_radius=12)
                pygame.draw.rect(screen, (255, 225, 95) if is_sel else (75, 82, 98), r, width=3 if is_sel else 2, border_radius=12)

                swatch = pygame.Rect(r.x + 16, r.y + 14, r.width - 32, 34)
                pygame.draw.rect(surface=screen, color=surf["desk_color"], rect=swatch, border_radius=6)
                pygame.draw.rect(surface=screen, color=surf["border_color"], rect=swatch, width=2, border_radius=6)

                n_s = med_font.render(surf["name"], True, (255, 255, 255))
                t_s = small_font.render(surf["tagline"], True, (255, 225, 110) if is_sel else (160, 175, 195))
                screen.blit(n_s, n_s.get_rect(center=(r.centerx, r.y + 68)))
                screen.blit(t_s, t_s.get_rect(center=(r.centerx, r.y + 90)))

                words = surf["desc"].split(" ")
                line1 = " ".join(words[:4])
                line2 = " ".join(words[4:])
                screen.blit(small_font.render(line1, True, (210, 215, 225)), small_font.render(line1, True, (0, 0, 0)).get_rect(center=(r.centerx, r.y + 118)))
                screen.blit(small_font.render(line2, True, (210, 215, 225)), small_font.render(line2, True, (0, 0, 0)).get_rect(center=(r.centerx, r.y + 138)))

            if game_mode == "freeplay":
                b_lbl = font.render("2. Tap Series Length (Best Of)", True, (200, 210, 225))
                screen.blit(b_lbl, b_lbl.get_rect(center=(WIDTH // 2, 378)))
                for i, bo_val in enumerate(SERIES_OPTIONS):
                    r = BO_RECTS[i]
                    is_sel = (best_of_target == bo_val)
                    hov = r.collidepoint(mouse_pos)
                    pygame.draw.rect(screen, (55, 145, 230) if is_sel else (CARD_HOVER if hov else CARD_BG), r, border_radius=8)
                    pygame.draw.rect(screen, (255, 235, 110) if is_sel else (80, 86, 102), r, width=2, border_radius=8)
                    txt = font.render(f"Best of {bo_val}", True, (255, 255, 255))
                    screen.blit(txt, txt.get_rect(center=r.center))

            s_hov = START_BTN_RECT.collidepoint(mouse_pos)
            pygame.draw.rect(screen, (60, 185, 120) if s_hov else (46, 155, 98), START_BTN_RECT, border_radius=12)
            st_txt = font.render("START MATCH", True, (255, 255, 255))
            screen.blit(st_txt, st_txt.get_rect(center=START_BTN_RECT.center))

        # ==========================================
        # RENDER: PENCIL BOX SELECTION ON DESK
        # ==========================================
        elif screen_state == "SELECT":
            screen.fill(FLOOR_COLOR)
            surf_spec = SURFACES[selected_surface_idx]
            draw_desk(screen, surf_spec, chalk_trails=[])
            draw_touch_button(screen, MENU_BTN_RECT, "MENU", CARD_BG, (95, 105, 125))

            picker = select_queue[0]
            active_theme = P1_THEME if picker == 0 else P2_THEME
            p_label = "Player 1" if picker == 0 else get_p2_name()

            if game_mode == "knockout" and koth_holder is not None:
                champ_theme = P1_THEME if koth_holder["player"] == 0 else P2_THEME
                champ_surf = render_pen_surface(
                    koth_holder["spec"],
                    champ_theme["primary"],
                    champ_theme["accent"],
                    cap_on=koth_holder.get("cap_on", True),
                )
                rotated = pygame.transform.rotate(champ_surf, -math.degrees(koth_holder["angle"]))
                rect = rotated.get_rect(center=koth_holder["pos"])
                screen.blit(rotated, rect.topleft)

            hovered_spec = draw_pencil_boxes(screen, mouse_pos, picker, open_box_player)

            prompt_box = pygame.Rect(DESK_RECT.centerx - 245, DESK_RECT.centery - 58, 490, 116)
            pygame.draw.rect(screen, (30, 34, 44), prompt_box, border_radius=12)
            pygame.draw.rect(screen, active_theme["primary"], prompt_box, width=3, border_radius=12)

            if round_banner:
                rb_s = small_font.render(round_banner, True, (255, 225, 100))
                screen.blit(rb_s, rb_s.get_rect(center=(prompt_box.centerx, prompt_box.y + 18)))

            action_str = (
                f"{p_label}: Tap your PENCIL BOX to open it!"
                if open_box_player != picker
                else f"{p_label}: Tap an item in your open box"
            )
            p_hdr = font.render(action_str, True, active_theme["accent"])
            screen.blit(p_hdr, p_hdr.get_rect(center=(prompt_box.centerx, prompt_box.y + 46)))

            if hovered_spec is not None:
                stat_line = f"{hovered_spec['name']}: {hovered_spec['strength']} | {hovered_spec['weakness']}"
                info_s = small_font.render(stat_line, True, (245, 245, 250))
            else:
                info_s = small_font.render(f"Surface: {surf_spec['name']} ({surf_spec['tagline']})", True, (190, 195, 210))
            screen.blit(info_s, info_s.get_rect(center=(prompt_box.centerx, prompt_box.y + 82)))

        # ==========================================
        # RENDER & PHYSICS: MATCHPLAY
        # ==========================================
        elif screen_state == "PLAY":
            surf_spec = SURFACES[selected_surface_idx]
            was_moving = not pens_stopped(pens)

            if match_winner is None:
                sub_dt = 1.0 / (60.0 * PHYSICS_SUBSTEPS)
                for _ in range(PHYSICS_SUBSTEPS):
                    active_sim_pens = []
                    for idx, p in enumerate(pens):
                        body = p["body"]
                        if out_flags[idx]:
                            out_dx = body.position.x - DESK_RECT.centerx
                            out_dy = body.position.y - DESK_RECT.centery
                            dist_c = max(1.0, math.hypot(out_dx, out_dy))
                            body.velocity = (
                                body.velocity.x + (out_dx / dist_c) * 140.0 * sub_dt,
                                body.velocity.y + (out_dy / dist_c) * 140.0 * sub_dt,
                            )
                            body.angular_velocity += 0.04 * (1 if idx == 0 else -1)
                        else:
                            if p["spec"]["id"] == "chalk" and body.velocity.length > 22 and random.random() < 0.25:
                                chalk_trails.append((body.position.x, body.position.y))
                                if len(chalk_trails) > 260:
                                    chalk_trails.pop(0)
                            active_sim_pens.append(p)

                    step_desk_physics(space, active_sim_pens, surf_spec, sub_dt)

                    if not pen_touched_this_shot and pens_touching(pens[0], pens[1], padding=2.0):
                        pen_touched_this_shot = True

                    for idx in (0, 1):
                        if not out_flags[idx] and is_off_desk(pens[idx]):
                            out_flags[idx] = True
                            if falling_timer == 0:
                                falling_timer = FALL_ANIM_FRAMES

                if falling_timer > 0:
                    falling_timer -= 1
                    if falling_timer == 0:
                        resolve_round_outcome()

                elif was_moving and pens_stopped(pens) and game_mode == "tactical":
                    if shot_count_in_round >= 2 and not pen_touched_this_shot:
                        active_boost_player = turn
                        b_spec = pens[turn]["spec"]
                        b_label = "Player 1" if turn == 0 else get_p2_name()
                        boost_notice = f"NO CONTACT! {b_label} gets {b_spec['boost_desc']}"

                if screen_state == "PLAY" and falling_timer == 0 and match_winner is None and pens_stopped(pens) and is_cpu_turn():
                    if cpu_think_timer == 0:
                        cpu_think_timer = 52
                        g_pt, p_vec, do_cap = cpu_plan_shot()
                        if do_cap:
                            toggle_pen_cap(space, pens[1])
                        cpu_planned_shot = (g_pt, p_vec)
                    else:
                        cpu_think_timer -= 1
                        if cpu_think_timer == 0 and cpu_planned_shot is not None:
                            g_pt, p_vec = cpu_planned_shot
                            cpu_planned_shot = None
                            execute_flick(1, g_pt, p_vec)

            if screen_state == "PLAY":
                screen.fill(FLOOR_COLOR)
                draw_desk(screen, surf_spec, chalk_trails)
                draw_pencil_boxes(screen, mouse_pos, picking_player=None, open_box_player=None)

                mode_lbl = next(m["title"] for m in MODES if m["id"] == game_mode)
                top_info = f"{mode_lbl} • {surf_spec['name']}"
                screen.blit(med_font.render(top_info, True, (185, 195, 215)), med_font.render(top_info, True, (0, 0, 0)).get_rect(center=(WIDTH // 2, 20)))

                can_human_act = (
                    not is_cpu_turn()
                    and falling_timer == 0
                    and match_winner is None
                    and pens_stopped(pens)
                    and not dragging
                )

                if can_human_act:
                    body = pens[turn]["body"]
                    ring_color = (255, 225, 75) if active_boost_player == turn else (255, 255, 255)
                    pygame.draw.circle(screen, ring_color, (int(body.position.x), int(body.position.y)), 76, width=3 if active_boost_player == turn else 2)

                for idx, p in enumerate(pens):
                    f_scale = 1.0
                    if out_flags[idx] and falling_timer > 0:
                        progress = 1.0 - (falling_timer / float(FALL_ANIM_FRAMES))
                        f_scale = max(0.55, 1.0 - progress * 0.45)
                    draw_pen(screen, p, boosted=(game_mode == "tactical" and active_boost_player == idx), fall_scale=f_scale)

                if dragging:
                    body = pens[turn]["body"]
                    anchor_world = body.local_to_world(grab_local)
                    dx = anchor_world.x - mouse_pos[0]
                    dy = anchor_world.y - mouse_pos[1]
                    raw_dist = math.hypot(dx, dy)
                    pull_dist = min(raw_dist, MAX_PULL)
                    angle = math.atan2(dy, dx)

                    power_ratio = pull_dist / float(MAX_PULL)
                    aim_color = (
                        int(min(255, power_ratio * 510)),
                        int(min(255, (1 - power_ratio) * 510 + 80)),
                        60
                    )

                    end_x = anchor_world.x + math.cos(angle) * (pull_dist * 1.15)
                    end_y = anchor_world.y + math.sin(angle) * (pull_dist * 1.15)
                    draw_dotted_line(screen, aim_color, (anchor_world.x, anchor_world.y), (end_x, end_y))

                    pull_x = anchor_world.x - math.cos(angle) * pull_dist
                    pull_y = anchor_world.y - math.sin(angle) * pull_dist
                    pygame.draw.line(screen, (255, 255, 255), (anchor_world.x, anchor_world.y), (pull_x, pull_y), 2)
                    pygame.draw.circle(screen, aim_color, (int(anchor_world.x), int(anchor_world.y)), 6)

                elif is_cpu_turn() and 0 < cpu_think_timer <= 34 and cpu_planned_shot is not None:
                    g_pt, p_vec = cpu_planned_shot
                    body = pens[1]["body"]
                    anchor_world = body.local_to_world(g_pt)
                    progress = 1.0 - (cpu_think_timer / 34.0)
                    cur_dx = p_vec[0] * progress
                    cur_dy = p_vec[1] * progress
                    pull_dist = math.hypot(cur_dx, cur_dy)
                    angle = math.atan2(cur_dy, cur_dx)
                    pull_x = anchor_world.x - math.cos(angle) * pull_dist
                    pull_y = anchor_world.y - math.sin(angle) * pull_dist
                    pygame.draw.line(screen, (255, 175, 175), (anchor_world.x, anchor_world.y), (pull_x, pull_y), 2)
                    pygame.draw.circle(screen, (255, 120, 120), (int(anchor_world.x), int(anchor_world.y)), 6)

                if match_winner:
                    win_surf = big_font.render(match_winner, True, (255, 225, 95))
                    screen.blit(win_surf, win_surf.get_rect(center=(WIDTH // 2, 122)))
                    draw_touch_button(screen, REPLAY_BTN_RECT, "PLAY AGAIN", (46, 155, 98), (110, 230, 160))
                    draw_touch_button(screen, END_MENU_BTN_RECT, "MAIN MENU", CARD_BG, (130, 140, 160))
                elif falling_timer > 0:
                    p2_out_lbl = f"{get_p2_name().upper()} OUT!"
                    ko_txt = "DOUBLE RING-OUT!" if (out_flags[0] and out_flags[1]) else ("PLAYER 1 OUT!" if out_flags[0] else p2_out_lbl)
                    ko_surf = big_font.render(ko_txt, True, (255, 225, 95))
                    screen.blit(ko_surf, ko_surf.get_rect(center=(WIDTH // 2, 122)))
                else:
                    draw_touch_button(screen, MENU_BTN_RECT, "MENU", CARD_BG, (95, 105, 125))
                    active_pen = pens[turn]

                    if is_cpu_turn() and pens_stopped(pens):
                        status = f"{get_p2_name()} is aiming..."
                    else:
                        status = f"Turn: {active_pen['name']}" if pens_stopped(pens) else "Pens moving..."
                    screen.blit(font.render(status, True, (240, 240, 240)), font.render(status, True, (0, 0, 0)).get_rect(center=(WIDTH // 2, 48)))

                    # Touch Cap On/Off Toggle Button
                    if can_human_act and active_pen["spec"].get("has_cap", False):
                        if active_pen["cap_toggled_this_round"]:
                            st_lbl = "CAP ON (Used)" if active_pen["cap_on"] else "CAP OFF (Used)"
                            draw_touch_button(screen, CAP_BTN_RECT, st_lbl, (36, 40, 50), (75, 82, 96), (135, 142, 155))
                        else:
                            st_lbl = "TAP: CAP ON -> OFF" if active_pen["cap_on"] else "TAP: CAP OFF -> ON"
                            draw_touch_button(screen, CAP_BTN_RECT, st_lbl, (48, 66, 96), (130, 185, 255), (255, 240, 140))

                    # Touch Rotate Buttons when Rubber Grip Boost is active
                    if (
                        can_human_act
                        and game_mode == "tactical"
                        and active_boost_player == turn
                        and active_pen["spec"]["id"] == "rubber_grip"
                    ):
                        draw_touch_button(screen, ROT_LEFT_RECT, "< ROTATE", (72, 62, 34), (255, 220, 90), (255, 235, 140))
                        draw_touch_button(screen, ROT_RIGHT_RECT, "ROTATE >", (72, 62, 34), (255, 220, 90), (255, 235, 140))

                    if boost_notice and active_boost_player == turn:
                        b_surf = med_font.render(boost_notice, True, (255, 225, 85))
                        screen.blit(b_surf, b_surf.get_rect(center=(WIDTH // 2, 126)))

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())